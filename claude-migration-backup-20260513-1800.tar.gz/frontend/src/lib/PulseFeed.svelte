<script>
	import { onMount, onDestroy } from 'svelte';
	import { apiJson, getToken } from '$lib/api.ts';

	let events = $state([]);
	let unreadCount = $state(0);
	let byType = $state({ notification: 0, jd_agent: 0, ai_scan: 0, ai_match: 0 });
	let open = $state(false);
	let activeTab = $state('all');
	let loading = $state(false);

	let es = null;
	let reconnectHandle = null;
	let containerEl;

	const TABS = [
		{ key: 'all',          label: 'ALL',   icon: '' },
		{ key: 'pipeline',     label: 'PIPE',  icon: '⏳' },
		{ key: 'notification', label: 'NOTIF', icon: '🔔' },
		{ key: 'jd_agent',     label: 'JD',    icon: '🤖' },
		{ key: 'ai',           label: 'AI',    icon: '✨' }
	];

	let pipeStats = $state({ running: 0, queued: 0, queue_depth: 0 });
	let pipeRows = $state([]);
	let pipePollHandle = null;

	async function loadPipeline() {
		try {
			const [qs, pend] = await Promise.all([
				apiJson('/candidates/queue-status').catch(() => ({})),
				apiJson('/candidates/pending?include_recent=true&limit=20').catch(() => ({}))
			]);
			pipeStats = {
				running: qs.running || 0,
				queued: qs.queued || 0,
				queue_depth: qs.queue_depth || 0
			};
			pipeRows = (pend.candidates || pend.pending || []).slice(0, 20);
		} catch { /* ignore */ }
	}

	function openCli(row) {
		window.dispatchEvent(new CustomEvent('hire-cli-open', { detail: { candidateId: row.id, runId: row.run_id || null } }));
		open = false;
	}

	function iconForType(type) {
		const map = {
			notification: '🔔',
			jd_agent: '🤖',
			ai_scan: '✨',
			ai_match: '✨'
		};
		return map[type] || '•';
	}

	function relativeTime(ts) {
		if (!ts) return '';
		const diff = Math.floor((Date.now() - new Date(ts).getTime()) / 1000);
		if (diff < 60) return 'just now';
		if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
		if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
		return `${Math.floor(diff / 86400)}d ago`;
	}

	let filteredEvents = $derived.by(() => {
		if (activeTab === 'all') return events;
		if (activeTab === 'ai') return events.filter((e) => e.type === 'ai_scan' || e.type === 'ai_match');
		return events.filter((e) => e.type === activeTab);
	});

	let tabCounts = $derived({
		all: events.length,
		pipeline: pipeStats.running + pipeStats.queued,
		notification: byType.notification || 0,
		jd_agent: byType.jd_agent || 0,
		ai: (byType.ai_scan || 0) + (byType.ai_match || 0)
	});

	async function loadFeed() {
		loading = true;
		try {
			const data = await apiJson('/feed?limit=50');
			events = (data?.events || []).slice(0, 100);
			unreadCount = data?.unread_count || 0;
			byType = data?.by_type || { notification: 0, jd_agent: 0, ai_scan: 0, ai_match: 0 };
		} catch {
			/* non-critical */
		} finally {
			loading = false;
		}
	}

	function pushEvent(ev) {
		if (!ev || !ev.id) return;
		// dedup by id
		if (events.find((e) => e.id === ev.id)) return;
		events = [ev, ...events].slice(0, 100);
		if (!ev.read) {
			unreadCount += 1;
			if (ev.type === 'notification') byType = { ...byType, notification: (byType.notification || 0) + 1 };
			else if (ev.type === 'jd_agent') byType = { ...byType, jd_agent: (byType.jd_agent || 0) + 1 };
			else if (ev.type === 'ai_scan') byType = { ...byType, ai_scan: (byType.ai_scan || 0) + 1 };
			else if (ev.type === 'ai_match') byType = { ...byType, ai_match: (byType.ai_match || 0) + 1 };
		}
	}

	function connectSSE() {
		try {
			const tok = getToken();
			if (!tok) return;
			es = new EventSource(`/api/feed/events?token=${encodeURIComponent(tok)}`);
			es.addEventListener('feed', (e) => {
				try {
					const data = JSON.parse(e.data);
					pushEvent(data);
				} catch { /* ignore parse errors */ }
			});
			es.onerror = () => {
				try { es && es.close(); } catch {}
				es = null;
				if (reconnectHandle) clearTimeout(reconnectHandle);
				reconnectHandle = setTimeout(connectSSE, 5000);
			};
		} catch {
			if (reconnectHandle) clearTimeout(reconnectHandle);
			reconnectHandle = setTimeout(connectSSE, 5000);
		}
	}

	async function markAllRead() {
		try {
			await apiJson('/feed/mark-all-read', { method: 'POST' });
			events = events.map((e) => ({ ...e, read: true }));
			unreadCount = 0;
			byType = { notification: 0, jd_agent: 0, ai_scan: 0, ai_match: 0 };
		} catch { /* ignore */ }
	}

	async function rowClick(ev) {
		if (!ev.read) {
			try {
				await apiJson('/feed/mark-read', { method: 'POST', body: JSON.stringify({ ids: [ev.id] }) });
				ev.read = true;
				events = [...events];
				unreadCount = Math.max(0, unreadCount - 1);
			} catch { /* ignore */ }
		}
		if (ev.action_url) {
			open = false;
			window.location.href = ev.action_url;
		}
	}

	function toggle() {
		open = !open;
		if (open) {
			loadFeed();
			loadPipeline();
			if (!pipePollHandle) pipePollHandle = setInterval(loadPipeline, 2000);
		} else {
			if (pipePollHandle) { clearInterval(pipePollHandle); pipePollHandle = null; }
		}
	}

	function onFeedRefresh() {
		loadFeed();
		loadPipeline();
	}

	function onDocClick(e) {
		if (!open) return;
		if (containerEl && !containerEl.contains(e.target)) open = false;
	}
	function onKey(e) {
		if (e.key === 'Escape' && open) open = false;
	}

	onMount(() => {
		loadFeed();
		connectSSE();
		document.addEventListener('click', onDocClick);
		document.addEventListener('keydown', onKey);
		window.addEventListener('pulse-feed-refresh', onFeedRefresh);
	});
	onDestroy(() => {
		try { es && es.close(); } catch {}
		if (reconnectHandle) clearTimeout(reconnectHandle);
		if (pipePollHandle) clearInterval(pipePollHandle);
		if (typeof document !== 'undefined') {
			document.removeEventListener('click', onDocClick);
			document.removeEventListener('keydown', onKey);
		}
		if (typeof window !== 'undefined') window.removeEventListener('pulse-feed-refresh', onFeedRefresh);
	});
</script>

<div class="pulse-feed-area" bind:this={containerEl}>
	<button class="pulse-trigger" onclick={toggle} aria-label="Pulse Feed">
		<span class="pf-bell">🔔</span>
		<span class="pf-label">PULSE FEED</span>
		<span class="pf-count">· {unreadCount}</span>
		{#if unreadCount > 0}
			<span class="pf-dot"></span>
		{/if}
	</button>

	{#if open}
		<div class="pf-panel" role="dialog">
			<div class="pf-tabs">
				{#each TABS as t}
					<button
						class="pf-tab"
						class:pf-tab-active={activeTab === t.key}
						onclick={() => (activeTab = t.key)}
					>
						{#if t.icon}<span>{t.icon}</span>{/if}
						<span>{t.label}</span>
						<span class="pf-tab-count">{tabCounts[t.key] ?? 0}</span>
					</button>
				{/each}
			</div>

			<div class="pf-body">
				{#if activeTab === 'pipeline'}
					<div class="pf-pipe-stats">
						▶ {pipeStats.running} RUNNING · ⏱ {pipeStats.queued} QUEUED · DEPTH {pipeStats.queue_depth}
						<button class="pf-pipe-cli" onclick={() => { window.dispatchEvent(new CustomEvent('hire-cli-open', { detail: {} })); open = false; }}>
							OPEN CLI →
						</button>
					</div>
					{#if pipeRows.length === 0}
						<div class="pf-empty">NO ACTIVE PIPELINE RUNS</div>
					{:else}
						{#each pipeRows as r (r.id)}
							<button class="pf-row" onclick={() => openCli(r)}>
								<span class="pf-row-icon">{r.is_processed ? '✓' : (r.processing_error ? '✗' : '⏳')}</span>
								<span class="pf-row-main">
									<span class="pf-row-title">cv_{String(r.id).padStart(3, '0')} · {(r.file_name || r.name || 'unknown').slice(0, 40)}</span>
									<span class="pf-row-sub">
										{#if r.processing_error}error · {r.processing_error.slice(0, 40)}
										{:else if r.is_processed}done · {r.quality_score ?? '-'} qual
										{:else}{r.last_step || 'queued'} · {r.last_status || ''}{/if}
									</span>
								</span>
								<span class="pf-row-ts">→ CLI</span>
							</button>
						{/each}
					{/if}
				{:else if loading}
					<div class="pf-empty">LOADING...</div>
				{:else if filteredEvents.length === 0}
					<div class="pf-empty">NO EVENTS</div>
				{:else}
					{#each filteredEvents as ev (ev.id)}
						<button
							class="pf-row"
							class:pf-unread={!ev.read}
							onclick={() => rowClick(ev)}
						>
							<span class="pf-row-icon">{iconForType(ev.type)}</span>
							<span class="pf-row-main">
								<span class="pf-row-title">{ev.title}</span>
								{#if ev.subtitle}
									<span class="pf-row-sub">{ev.subtitle}</span>
								{/if}
							</span>
							<span class="pf-row-ts">{relativeTime(ev.ts)}</span>
						</button>
					{/each}
				{/if}
			</div>

			<div class="pf-footer">
				<button class="pf-foot-btn" onclick={markAllRead}>MARK ALL READ</button>
				<button class="pf-foot-btn pf-foot-link" onclick={() => loadFeed()}>↻ REFRESH</button>
			</div>
		</div>
	{/if}
</div>

<style>
	.pulse-feed-area {
		position: relative;
		font-family: 'Space Grotesk', sans-serif;
	}
	.pulse-trigger {
		position: relative;
		display: inline-flex;
		align-items: center;
		gap: 6px;
		padding: 4px 10px;
		background: #feffd6;
		color: #383832;
		border: 2px solid #383832;
		border-right-width: 4px;
		border-bottom-width: 4px;
		border-radius: 0;
		box-shadow: 4px 4px 0 #007518;
		cursor: pointer;
		text-transform: uppercase;
		font-weight: 900;
		font-size: 10px;
		letter-spacing: 0.08em;
		font-family: 'Space Grotesk', sans-serif;
	}
	.pulse-trigger:hover { background: #00fc40; }
	.pf-bell { font-size: 12px; }
	.pf-label { font-weight: 900; }
	.pf-count { opacity: 0.75; }
	.pf-dot {
		position: absolute;
		top: -4px;
		right: -4px;
		width: 10px;
		height: 10px;
		background: #ff2a2a;
		border: 2px solid #383832;
	}

	.pf-panel {
		position: absolute;
		top: calc(100% + 8px);
		right: 0;
		width: 380px;
		max-height: 600px;
		background: #feffd6;
		color: #383832;
		border: 2px solid #383832;
		border-right-width: 4px;
		border-bottom-width: 4px;
		border-radius: 0;
		box-shadow: 4px 4px 0 #383832;
		z-index: 200;
		display: flex;
		flex-direction: column;
	}

	.pf-tabs {
		display: flex;
		gap: 0;
		border-bottom: 2px solid #383832;
		background: #383832;
	}
	.pf-tab {
		flex: 1;
		display: inline-flex;
		align-items: center;
		justify-content: center;
		gap: 4px;
		padding: 6px 4px;
		background: #383832;
		color: #feffd6;
		border: none;
		border-right: 1px solid #555;
		border-radius: 0;
		font-family: 'Space Grotesk', sans-serif;
		font-weight: 900;
		font-size: 9px;
		letter-spacing: 0.08em;
		text-transform: uppercase;
		cursor: pointer;
	}
	.pf-tab:last-child { border-right: none; }
	.pf-tab-active {
		background: #00fc40;
		color: #383832;
	}
	.pf-tab-count {
		font-size: 8px;
		opacity: 0.75;
	}

	.pf-body {
		overflow-y: auto;
		max-height: 480px;
		flex: 1;
		background: #feffd6;
	}
	.pf-empty {
		padding: 32px 12px;
		text-align: center;
		font-size: 10px;
		font-weight: 900;
		letter-spacing: 0.1em;
		color: #888;
		text-transform: uppercase;
	}
	.pf-row {
		display: grid;
		grid-template-columns: 22px 1fr auto;
		gap: 8px;
		align-items: flex-start;
		padding: 8px 10px;
		width: 100%;
		background: #feffd6;
		border: none;
		border-bottom: 1px solid #e5e5c8;
		border-left: 4px solid transparent;
		border-radius: 0;
		text-align: left;
		cursor: pointer;
		font-family: 'Space Grotesk', sans-serif;
	}
	.pf-row:hover { background: #f3f3c0; }
	.pf-unread {
		background: #f8ffe5;
		border-left-color: #00fc40;
	}
	.pf-row-icon {
		font-size: 14px;
		line-height: 1.2;
	}
	.pf-row-main {
		display: flex;
		flex-direction: column;
		min-width: 0;
	}
	.pf-row-title {
		font-size: 11px;
		font-weight: 900;
		color: #383832;
		line-height: 1.3;
		text-transform: uppercase;
		letter-spacing: 0.03em;
	}
	.pf-row-sub {
		font-size: 10px;
		color: #666;
		margin-top: 2px;
		line-height: 1.3;
	}
	.pf-row-ts {
		font-size: 9px;
		color: #007518;
		font-weight: 700;
		letter-spacing: 0.06em;
		text-transform: uppercase;
		white-space: nowrap;
	}

	.pf-footer {
		display: flex;
		justify-content: space-between;
		gap: 6px;
		padding: 6px 8px;
		border-top: 2px solid #383832;
		background: #feffd6;
	}
	.pf-foot-btn {
		flex: 1;
		display: inline-flex;
		align-items: center;
		justify-content: center;
		padding: 5px 8px;
		background: #feffd6;
		color: #383832;
		border: 2px solid #383832;
		border-right-width: 4px;
		border-bottom-width: 4px;
		border-radius: 0;
		font-family: 'Space Grotesk', sans-serif;
		font-weight: 900;
		font-size: 9px;
		letter-spacing: 0.1em;
		text-transform: uppercase;
		cursor: pointer;
		text-decoration: none;
		text-align: center;
	}
	.pf-foot-btn:hover { background: #00fc40; }
	.pf-foot-link { color: #007518; }

	.pf-pipe-stats {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 8px 10px;
		background: #007518;
		color: #feffd6;
		font-size: 10px;
		font-weight: 900;
		letter-spacing: 0.06em;
		text-transform: uppercase;
		border-bottom: 2px solid #383832;
	}
	.pf-pipe-cli {
		padding: 4px 8px;
		background: #00fc40;
		color: #383832;
		border: 2px solid #383832;
		font-family: inherit;
		font-size: 9px;
		font-weight: 900;
		letter-spacing: 0.08em;
		text-transform: uppercase;
		cursor: pointer;
	}
	.pf-pipe-cli:hover { background: #feffd6; }
</style>
