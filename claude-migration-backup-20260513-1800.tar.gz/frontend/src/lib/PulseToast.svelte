<script>
	import { onMount, onDestroy } from 'svelte';

	let toasts = $state([]);
	let nextId = 0;

	function onToast(e) {
		const d = e.detail || {};
		const id = ++nextId;
		const ttl = d.ttl || 5000;
		toasts = [...toasts, {
			id,
			kind: d.kind || 'info',
			filename: d.filename || '',
			candidateId: d.candidateId || null,
			runId: d.runId || null,
			text: d.text || ''
		}];
		setTimeout(() => dismiss(id), ttl);
	}

	function dismiss(id) {
		toasts = toasts.filter(t => t.id !== id);
	}

	function openCli(t) {
		if (t.kind === 'dedup' && t.candidateId) {
			window.location.href = `/candidates/${t.candidateId}`;
		} else {
			window.dispatchEvent(new CustomEvent('hire-cli-open', { detail: { runId: t.runId, candidateId: t.candidateId } }));
		}
		dismiss(t.id);
	}

	onMount(() => {
		window.addEventListener('pulse-toast', onToast);
	});
	onDestroy(() => {
		if (typeof window !== 'undefined') window.removeEventListener('pulse-toast', onToast);
	});
</script>

<div class="pt-stack">
	{#each toasts as t (t.id)}
		<div class="pt-toast" class:pt-pipeline={t.kind === 'pipeline'} class:pt-dedup={t.kind === 'dedup'}>
			<button class="pt-body" onclick={() => openCli(t)} title={t.kind === 'dedup' ? 'View existing CV' : 'Open pipeline terminal'}>
				<span class="pt-icon">{t.kind === 'pipeline' ? '⏳' : t.kind === 'dedup' ? '⊙' : '•'}</span>
				<span class="pt-main">
					<span class="pt-title">
						{#if t.kind === 'pipeline'}CV INGEST · QUEUED
						{:else if t.kind === 'dedup'}DUPLICATE · SKIPPED
						{:else}EVENT{/if}
					</span>
					<span class="pt-sub">{t.filename || ''}{t.text ? ' · ' + t.text : ''}</span>
				</span>
				<span class="pt-arrow">{t.kind === 'dedup' ? '→ CV' : '→ CLI'}</span>
			</button>
			<button class="pt-x" onclick={() => dismiss(t.id)} aria-label="dismiss">×</button>
		</div>
	{/each}
</div>

<style>
	.pt-stack {
		position: fixed;
		top: 64px;
		right: 16px;
		z-index: 5000;
		display: flex;
		flex-direction: column;
		gap: 8px;
		font-family: 'Space Grotesk', sans-serif;
		pointer-events: none;
	}
	.pt-toast {
		display: flex;
		align-items: stretch;
		min-width: 300px;
		max-width: 380px;
		background: #feffd6;
		color: #383832;
		border: 2px solid #383832;
		border-right-width: 4px;
		border-bottom-width: 4px;
		box-shadow: 4px 4px 0 #007518;
		pointer-events: auto;
		animation: pt-in 180ms ease-out;
	}
	.pt-pipeline { box-shadow: 4px 4px 0 #00fc40; }
	.pt-dedup    { box-shadow: 4px 4px 0 #ff8c00; border-color: #ff8c00; }
	.pt-dedup .pt-title { color: #ff8c00; }
	.pt-body {
		flex: 1;
		display: grid;
		grid-template-columns: 22px 1fr auto;
		gap: 8px;
		align-items: center;
		padding: 8px 10px;
		background: transparent;
		color: inherit;
		border: none;
		text-align: left;
		cursor: pointer;
		font-family: inherit;
	}
	.pt-body:hover { background: #f3f3c0; }
	.pt-icon { font-size: 14px; }
	.pt-main { display: flex; flex-direction: column; min-width: 0; }
	.pt-title {
		font-size: 10px;
		font-weight: 900;
		letter-spacing: 0.08em;
		text-transform: uppercase;
		color: #007518;
	}
	.pt-sub {
		font-size: 11px;
		color: #383832;
		margin-top: 2px;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
	.pt-arrow {
		font-size: 9px;
		font-weight: 900;
		letter-spacing: 0.1em;
		color: #007518;
		text-transform: uppercase;
	}
	.pt-x {
		padding: 0 10px;
		background: #383832;
		color: #feffd6;
		border: none;
		border-left: 2px solid #383832;
		font-size: 16px;
		font-weight: 900;
		cursor: pointer;
	}
	.pt-x:hover { background: #ff2a2a; }

	@keyframes pt-in {
		from { transform: translateX(20px); opacity: 0; }
		to { transform: translateX(0); opacity: 1; }
	}
</style>
