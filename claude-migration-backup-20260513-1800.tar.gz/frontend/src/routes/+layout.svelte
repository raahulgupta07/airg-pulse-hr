<script>
	import '../app.css';
	import Toast from '$lib/Toast.svelte';
	import PipelineTerminal from '$lib/PipelineTerminal.svelte';
	import PulseFeed from '$lib/PulseFeed.svelte';
	import PulseToast from '$lib/PulseToast.svelte';
	import { apiJson } from '$lib/api.ts';
	import { logout } from '$lib/auth';
	import { page } from '$app/state';

	let { data, children } = $props();
	let currentUser = $derived(data?.user ?? null);
	let operatorLabel = $derived(
		currentUser?.operator_id || currentUser?.email || currentUser?.display_name || ''
	);

	let currentPath = $derived(page.url?.pathname || '/');
	let systemStatus = $state('active');

	// Notifications
	let notifCount = $state(0);
	let notifications = $state([]);
	let showNotifPanel = $state(false);
	let notifLoading = $state(false);

	// Merge proposals (pending count)
	let mergePendingCount = $state(0);
	async function fetchMergeCount() {
		try {
			const data = await apiJson('/merges/pending-count');
			mergePendingCount = data.total || 0;
		} catch { /* non-critical */ }
	}

	$effect(() => {
		if (typeof window === 'undefined') return;

		// Skip heavy chrome work on public/auth routes (no token yet)
		const path = window.location.pathname;
		if (['/login', '/register', '/careers'].some((p) => path === p || path.startsWith(p + '/'))) {
			return;
		}

		const onClick = (e) => {
			if (showNotifPanel && !e.target.closest('.notif-area')) {
				showNotifPanel = false;
			}
		};
		document.addEventListener('click', onClick);

		loadFeatures();
		fetchNotifCount();
		fetchMergeCount();
		const interval = setInterval(() => { fetchNotifCount(); fetchMergeCount(); }, 30000);
		return () => {
			clearInterval(interval);
			document.removeEventListener('click', onClick);
		};
	});

	async function fetchNotifCount() {
		try {
			const data = await apiJson('/notifications/count');
			notifCount = data.count || 0;
		} catch { /* non-critical */ }
	}

	async function fetchNotifications() {
		notifLoading = true;
		try {
			const data = await apiJson('/notifications');
			notifications = data.notifications || [];
		} catch {
			notifications = [];
		} finally {
			notifLoading = false;
		}
	}

	function toggleNotifPanel() {
		showNotifPanel = !showNotifPanel;
		if (showNotifPanel) fetchNotifications();
	}

	async function markRead(notif) {
		try {
			await apiJson(`/notifications/read/${notif.id}`, { method: 'POST' });
			notif.is_read = true;
			notifications = [...notifications];
			notifCount = Math.max(0, notifCount - 1);
		} catch { /* ignore */ }
		if (notif.link) {
			showNotifPanel = false;
			window.location.href = notif.link;
		}
	}

	async function markAllRead() {
		try {
			await apiJson('/notifications/read-all', { method: 'POST' });
			notifications = notifications.map(n => ({ ...n, is_read: true }));
			notifCount = 0;
		} catch { /* ignore */ }
	}

	function timeAgo(dateStr) {
		if (!dateStr) return '';
		const diff = Math.floor((Date.now() - new Date(dateStr).getTime()) / 1000);
		if (diff < 60) return 'just now';
		if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
		if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
		return `${Math.floor(diff / 86400)}d ago`;
	}

	const NAV_ALL = [
		{ path: '/', label: 'Positions', icon: 'work', flag: 'feature_positions' },
		{ path: '/jds', label: 'JD Repo', icon: 'description', flag: 'feature_jds' },
		{ path: '/candidates', label: 'CV Repo', icon: 'folder_shared', flag: 'feature_candidates' },
		{ path: '/analytics', label: 'Analytics', icon: 'analytics', flag: 'feature_analytics' },
		{ path: '/chat', label: 'HR Brain', icon: 'smart_toy', flag: 'feature_chat' },
		{ path: '/admin', label: 'Admin', icon: 'admin_panel_settings', flag: null },
		{ path: '/billing', label: 'Billing', icon: 'receipt_long', flag: null },
	];
	let features = $state(null);
	let navItems = $derived(features === null ? [] : NAV_ALL.filter(n => !n.flag || features[n.flag] !== false));

	async function loadFeatures() {
		try {
			const r = await fetch('/api/system/features');
			features = await r.json();
		} catch { features = {}; }
	}

	$effect(() => {
		if (!isPublicRoute && features === null) loadFeatures();
	});

	function isActive(path) {
		if (path === '/') return currentPath === '/' || currentPath === '';
		return currentPath.startsWith(path);
	}

	const PUBLIC_PREFIXES = ['/login', '/register', '/careers'];
	let isPublicRoute = $derived(
		PUBLIC_PREFIXES.some((p) => currentPath === p || currentPath.startsWith(p + '/'))
	);
</script>

{#if isPublicRoute}
	{@render children()}
{:else}
<div class="flex flex-col h-screen">
	<!-- Header -->
	<header class="flex items-center gap-3 px-4 h-[48px] flex-shrink-0" style="background: #383832; color: #feffd6;">
		<a href="/" class="flex items-center gap-2" style="text-decoration: none; color: inherit;">
			<div style="background: #00fc40; padding: 4px 8px; border: 2px solid #feffd6; display: flex; align-items: center;">
				<span class="material-symbols-outlined" style="font-size: 20px; color: #383832;">work</span>
			</div>
			<span style="font-size: 18px; font-weight: 900; letter-spacing: -0.03em; font-family: 'Space Grotesk';">PULSE</span>
		</a>

		<nav class="flex items-center gap-1 ml-4">
			{#each navItems as item}
				<a
					href={item.path}
					class="nav-btn"
					class:nav-btn-active={isActive(item.path)}
					style="text-decoration: none;"
				>
					<span class="material-symbols-outlined" style="font-size: 14px;">{item.icon}</span>
					<span class="hide-mobile" style="font-size: 10px; font-weight: 700; letter-spacing: 0.08em; text-transform: uppercase;">{item.label}</span>
				</a>
			{/each}
		</nav>

		<div class="ml-auto flex items-center gap-3">
			{#if mergePendingCount > 0}
				<a href="/admin#merges"
					title="{mergePendingCount} pending merge proposals"
					style="text-decoration: none; display: inline-flex; align-items: center; gap: 4px; border: 1.5px solid #feffd6; background: #c00; color: #feffd6; padding: 2px 8px; font-size: 9px; font-weight: 900; letter-spacing: 0.08em; text-transform: uppercase;">
					<span class="material-symbols-outlined" style="font-size: 12px;">merge_type</span>
					MERGES ({mergePendingCount})
				</a>
			{/if}
			<!-- Unified Pulse Feed (replaces bell + JD agent badge) -->
			<PulseFeed />


			{#if operatorLabel}
				<span class="hide-mobile op-id" title="Current operator">{operatorLabel}</span>
			{/if}
			{#if currentUser}
				<button class="logout-btn" onclick={logout} aria-label="Logout">LOGOUT</button>
			{/if}
		</div>
	</header>

	<!-- Main Content -->
	<main class="flex-1 overflow-hidden flex flex-col">
		<div class="flex-1 overflow-hidden">
			{@render children()}
		</div>
	</main>

	<!-- Footer -->
	<footer
		class="flex items-center justify-between px-4 h-[32px] flex-shrink-0"
		style="background: #007518; color: white;"
	>
		<div class="flex items-center gap-2">
			<div style="width: 6px; height: 6px; background: #00fc40; border: 1px solid white;"></div>
			<span style="font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em;">
				{systemStatus === 'active' ? 'SYSTEM_ACTIVE' : 'PROCESSING'}
			</span>
		</div>
		<span class="hide-mobile" style="font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.1em;">
			PULSE v1.0 · P · U · L · S · E
		</span>
	</footer>

	<Toast />
	<PulseToast />
	<PipelineTerminal />
</div>
{/if}

<style>
	@media (max-width: 768px) {
		.hide-mobile { display: none !important; }
	}

	/* Operator + Logout */
	.op-id {
		font-family: 'Space Grotesk', sans-serif;
		font-size: 11px;
		font-weight: 700;
		letter-spacing: 0.1em;
		text-transform: uppercase;
		color: #feffd6;
		opacity: 0.85;
		padding: 2px 6px;
		border-left: 1px solid rgba(254, 255, 214, 0.3);
		padding-left: 10px;
	}
	.logout-btn {
		font-family: 'Space Grotesk', sans-serif;
		font-size: 11px;
		font-weight: 700;
		letter-spacing: 0.15em;
		text-transform: uppercase;
		color: #feffd6;
		background: transparent;
		border: 1px solid #feffd6;
		padding: 4px 10px;
		cursor: pointer;
		border-radius: 0;
		transition: background 0.15s, color 0.15s, border-color 0.15s;
	}
	.logout-btn:hover {
		background: #c00;
		color: #feffd6;
		border-color: #c00;
	}
	.logout-btn:focus-visible {
		outline: 2px solid #00fc40;
		outline-offset: 2px;
	}

	/* Notification Bell */
	.notif-badge {
		position: absolute;
		top: 0;
		right: -2px;
		background: #ff4444;
		color: white;
		font-size: 9px;
		font-weight: 900;
		min-width: 16px;
		height: 16px;
		border-radius: 8px;
		display: flex;
		align-items: center;
		justify-content: center;
		line-height: 1;
		padding: 0 3px;
	}

	/* Notification Panel */
	.notif-panel {
		position: absolute;
		top: calc(100% + 8px);
		right: 0;
		width: 340px;
		max-height: 420px;
		background: white;
		border: 2px solid #383832;
		border-right-width: 4px;
		border-bottom-width: 4px;
		box-shadow: 6px 6px 0 rgba(56, 56, 50, 0.1);
		z-index: 100;
		display: flex;
		flex-direction: column;
	}
	.notif-panel-header {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 10px 14px;
		border-bottom: 1px solid #eee;
		color: #383832;
	}
	.notif-mark-all {
		background: none;
		border: none;
		color: #007518;
		font-size: 10px;
		font-weight: 700;
		text-transform: uppercase;
		letter-spacing: 0.06em;
		cursor: pointer;
		font-family: 'Space Grotesk', sans-serif;
	}
	.notif-mark-all:hover {
		text-decoration: underline;
	}
	.notif-panel-body {
		overflow-y: auto;
		flex: 1;
	}
	.notif-empty {
		padding: 2rem;
		text-align: center;
		color: #aaa;
		font-size: 12px;
	}
	.notif-item {
		display: flex;
		align-items: flex-start;
		gap: 8px;
		padding: 10px 14px;
		border-bottom: 1px solid #f5f5f0;
		cursor: pointer;
		width: 100%;
		background: none;
		border-left: none;
		border-right: none;
		border-top: none;
		text-align: left;
		font-family: 'Space Grotesk', sans-serif;
		transition: background 0.1s;
	}
	.notif-item:hover {
		background: #fafaf5;
	}
	.notif-unread {
		background: #f8fff0;
	}
	.notif-dot-wrap {
		width: 8px;
		flex-shrink: 0;
		padding-top: 5px;
	}
	.notif-dot {
		width: 8px;
		height: 8px;
		background: #00fc40;
		border: 1px solid #007518;
	}
	.notif-content {
		flex: 1;
		min-width: 0;
	}
	.notif-title {
		font-size: 12px;
		font-weight: 700;
		color: #383832;
		line-height: 1.3;
	}
	.notif-msg {
		font-size: 11px;
		color: #888;
		margin-top: 2px;
		line-height: 1.3;
	}
	.notif-time {
		font-size: 10px;
		color: #bbb;
		margin-top: 3px;
	}
</style>
