<script>
	/** Positions Grid — Home page */
	import { apiJson } from '$lib/api';
	import { addToast } from '$lib/Toast.svelte';

	let positions = $state([]);
	let loading = $state(true);
	let showCreate = $state(false);

	// Status filter: 'active' | 'all' | 'closed'
	let statusFilter = $state('active');

	// Create form
	let newTitle = $state('');
	let newDept = $state('');
	let newLocation = $state('');
	let newType = $state('full-time');
	let creating = $state(false);

	// Templates
	let templates = $state([]);
	let createMode = $state('blank'); // 'blank' | 'template'
	let selectedTemplateId = $state(null);
	let selectedTemplate = $derived(templates.find(t => t.id === selectedTemplateId));

	// Validation
	let titleTouched = $state(false);
	let deptTouched = $state(false);
	let titleError = $derived(
		titleTouched && newTitle.trim().length < 3 ? (newTitle.trim().length === 0 ? 'Title is required' : 'Title must be at least 3 characters') : ''
	);
	let deptWarning = $derived(deptTouched && !newDept.trim() ? 'Department recommended' : '');
	let titleValid = $derived(newTitle.trim().length >= 3);

	let headerLabel = $derived(
		statusFilter === 'active' ? `${positions.length} active position${positions.length !== 1 ? 's' : ''}`
		: statusFilter === 'closed' ? `${positions.length} closed position${positions.length !== 1 ? 's' : ''}`
		: `${positions.length} total position${positions.length !== 1 ? 's' : ''}`
	);

	$effect(() => {
		loadPositions();
		loadTemplates();
	});

	async function loadTemplates() {
		try {
			const data = await apiJson('/positions/templates');
			templates = data.templates || [];
		} catch (e) { /* templates table may not exist yet */ }
	}

	function applyTemplate(tpl) {
		selectedTemplateId = tpl.id;
		newTitle = tpl.title || '';
		newDept = tpl.department || '';
		newType = tpl.employment_type || 'full-time';
	}

	async function loadPositions() {
		loading = true;
		try {
			let url = '/positions';
			if (statusFilter === 'active') url += '?status=active';
			else if (statusFilter === 'closed') url += '?status=closed';
			const data = await apiJson(url);
			positions = data.positions || [];
		} catch (e) { addToast('error', e.message || 'Something went wrong'); console.error(e); }
		loading = false;
	}

	function setFilter(f) {
		statusFilter = f;
		loadPositions();
	}

	async function archivePosition(e, slug) {
		e.preventDefault();
		e.stopPropagation();
		try {
			await apiJson(`/positions/${slug}/archive`, { method: 'POST' });
			cliEvent('success', `Position archived`);
			await loadPositions();
		} catch (err) {
			cliEvent('error', `Archive failed: ${err.message}`);
		}
	}

	// --- Hard-delete position with double-confirm ---
	let posDeleteTarget = $state(null); // { slug, title }
	let posDeleteConfirmText = $state('');
	let posDeleting = $state(false);
	function askDeletePosition(e, pos) {
		e?.preventDefault?.(); e?.stopPropagation?.();
		posDeleteTarget = { slug: pos.slug, title: pos.title };
		posDeleteConfirmText = '';
	}
	async function confirmDeletePosition() {
		if (!posDeleteTarget) return;
		const ok = posDeleteConfirmText.trim().toLowerCase() === (posDeleteTarget.title || '').trim().toLowerCase()
			|| posDeleteConfirmText.trim().toUpperCase() === 'DELETE';
		if (!ok) {
			cliEvent('error', `Type position name "${posDeleteTarget.title}" or DELETE`);
			return;
		}
		posDeleting = true;
		try {
			const deletedSlug = posDeleteTarget.slug;
			await apiJson(`/positions/${deletedSlug}?hard=true`, { method: 'DELETE' });
			cliEvent('success', `Position "${posDeleteTarget.title}" permanently deleted`);
			posDeleteTarget = null;
			posDeleteConfirmText = '';
			positions = positions.filter(p => p.slug !== deletedSlug);
			await loadPositions();
		} catch (e) {
			cliEvent('error', `Delete failed: ${e.message}`);
		}
		posDeleting = false;
	}

	async function createPosition() {
		if (!newTitle.trim()) return;
		creating = true;
		try {
			let res;
			if (createMode === 'template' && selectedTemplateId) {
				res = await apiJson(`/positions/from-template/${selectedTemplateId}`, {
					method: 'POST',
					body: JSON.stringify({ title: newTitle, department: newDept, location: newLocation }),
				});
			} else {
				res = await apiJson('/positions/', {
					method: 'POST',
					body: JSON.stringify({ title: newTitle, department: newDept, location: newLocation, employment_type: newType }),
				});
			}
			const createdSlug = res.slug;
			showCreate = false;
			cliEvent('success', `Position "${newTitle}" created`);
			newTitle = ''; newDept = ''; newLocation = ''; newType = 'full-time';
			createMode = 'blank'; selectedTemplateId = null;
			await loadPositions();
			// Navigate to the new position
			if (createdSlug) window.location.href = `/positions/${createdSlug}`;
		} catch (e) {
			cliEvent('error', `Failed: ${e.message}`);
		}
		creating = false;
	}

	function cliEvent(type, text) {
		window.dispatchEvent(new CustomEvent('hire-cli', { detail: { type, text } }));
	}

	const stageColors = {
		uploaded: '#9d9d91', screened: '#006f7c', shortlisted: '#007518',
		interview_scheduled: '#ff9d00', offered: '#9d4867', hired: '#00fc40',
	};

	// --- Position Health Score (client-side calculation) ---
	function computeHealth(pos) {
		const cvCount = pos.cv_count || 0;
		const avgMatch = pos.avg_match || 0;
		const pipeline = pos.pipeline || {};
		const daysOpen = pos.days_open || 0;

		// Pipeline activity: count candidates beyond 'uploaded'
		const activePipeline = Object.entries(pipeline)
			.filter(([stage]) => stage !== 'uploaded' && stage !== 'rejected')
			.reduce((sum, [, count]) => sum + count, 0);

		// Pipeline activity score (0-100)
		const pipelineScore = cvCount > 0 ? Math.min(100, activePipeline * 20) : 0;
		// CV count score (0-100), target 10+
		const cvScore = Math.min(100, cvCount * 10);
		// Match quality (0-100)
		const matchScore = avgMatch;
		// Freshness (0-100), penalize > 60 days
		const freshness = daysOpen <= 60 ? Math.max(0, 100 - (daysOpen * 100 / 60)) : 0;

		return Math.round(
			pipelineScore * 0.25 +
			cvScore * 0.25 +
			matchScore * 0.30 +
			freshness * 0.20
		);
	}

	function healthColor(score) {
		if (score >= 70) return '#007518';
		if (score >= 40) return '#ff9d00';
		return '#be2d06';
	}

	function healthLabel(score) {
		if (score >= 70) return 'HEALTHY';
		if (score >= 40) return 'ATTENTION';
		return 'AT RISK';
	}
</script>

<div class="h-full overflow-y-auto p-6" style="max-width: 1800px; margin: 0 auto;">
	<!-- Header -->
	<div class="flex items-center justify-between mb-6 section-animate">
		<div>
			<h1 style="font-size: 24px; font-weight: 900; text-transform: uppercase; letter-spacing: -0.02em;">Positions</h1>
			<p style="font-size: 12px; color: var(--color-on-surface-dim); text-transform: uppercase; letter-spacing: 0.05em;">
				{headerLabel}
			</p>
		</div>
		<div class="flex items-center gap-2">
			<!-- Status Filter Toggle -->
			<div class="flex" style="border: 2px solid var(--color-on-surface);">
				{#each ['active', 'all', 'closed'] as f}
					<button
						onclick={() => setFilter(f)}
						style="padding: 6px 14px; font-family: 'Space Grotesk'; font-size: 10px; font-weight: 900; text-transform: uppercase; letter-spacing: 0.05em; border: none; cursor: pointer;
							background: {statusFilter === f ? 'var(--color-on-surface)' : 'var(--color-surface)'};
							color: {statusFilter === f ? 'var(--color-surface)' : 'var(--color-on-surface)'};"
					>{f}</button>
				{/each}
			</div>
			<button class="btn-secondary" onclick={() => { window.location.href = '/api/positions/export.csv'; }} title="Export positions as CSV">📥 Export CSV</button>
			<button class="send-btn" onclick={() => showCreate = true}>+ New Position</button>
		</div>
	</div>

	<!-- Create Modal -->
	{#if showCreate}
		<div style="position: fixed; inset: 0; background: rgba(56,56,50,0.7); z-index: 100; display: flex; align-items: center; justify-content: center;" onclick={(e) => { if (e.target === e.currentTarget) showCreate = false; }}>
			<div class="ink-border stamp-shadow animate-fade-up" style="background: var(--color-surface); width: 560px; max-height: 90vh; overflow-y: auto;">
				<div class="dark-title-bar flex items-center justify-between">
					<span>Create Position</span>
					<button onclick={() => showCreate = false} style="background: none; border: none; color: var(--color-surface); cursor: pointer; font-size: 16px;">✕</button>
				</div>
				<div class="p-5" style="display: flex; flex-direction: column; gap: 16px;">
					<!-- Template / Blank toggle -->
					<div class="flex" style="border: 2px solid var(--color-on-surface);">
						<button class="flex-1 py-2" style="font-size: 11px; font-weight: 900; text-transform: uppercase; letter-spacing: 0.06em; border: none; cursor: pointer;
							background: {createMode === 'blank' ? 'var(--color-on-surface)' : 'var(--color-surface-bright)'}; color: {createMode === 'blank' ? 'var(--color-primary-container)' : 'var(--color-on-surface)'};"
							onclick={() => { createMode = 'blank'; selectedTemplateId = null; }}>
							<span class="material-symbols-outlined" style="font-size: 14px; vertical-align: middle;">add</span> Blank
						</button>
						<button class="flex-1 py-2" style="font-size: 11px; font-weight: 900; text-transform: uppercase; letter-spacing: 0.06em; border: none; border-left: 2px solid var(--color-on-surface); cursor: pointer;
							background: {createMode === 'template' ? 'var(--color-on-surface)' : 'var(--color-surface-bright)'}; color: {createMode === 'template' ? 'var(--color-primary-container)' : 'var(--color-on-surface)'};"
							onclick={() => createMode = 'template'}>
							<span class="material-symbols-outlined" style="font-size: 14px; vertical-align: middle;">content_copy</span> From Template
						</button>
					</div>

					<!-- Template selector -->
					{#if createMode === 'template'}
						{#if templates.length === 0}
							<div style="padding: 12px; background: var(--color-surface-container); border-left: 3px solid var(--color-warning);">
								<p style="font-size: 11px; color: var(--color-on-surface-dim);">No templates saved yet. Create a position and save it as a template from the Settings tab.</p>
							</div>
						{:else}
							<div>
								<label class="tag-label mb-1" style="display: block;">Select Template</label>
								<div style="max-height: 160px; overflow-y: auto; border: 2px solid var(--color-on-surface);">
									{#each templates as tpl}
										<button class="w-full text-left p-2" style="border: none; border-bottom: 1px solid var(--color-surface-highest); cursor: pointer; font-family: 'Space Grotesk';
											background: {selectedTemplateId === tpl.id ? 'var(--color-on-surface)' : 'var(--color-surface-bright)'}; color: {selectedTemplateId === tpl.id ? 'var(--color-primary-container)' : 'var(--color-on-surface)'};"
											onclick={() => applyTemplate(tpl)}>
											<span style="font-size: 12px; font-weight: 900;">{tpl.name}</span>
											<span style="font-size: 10px; opacity: 0.7;"> — {tpl.title} · {tpl.department || 'No dept'}</span>
										</button>
									{/each}
								</div>
							</div>
						{/if}
					{/if}

					<div>
						<label class="tag-label mb-1" style="display: block;">Position Title *</label>
						<input bind:value={newTitle} placeholder="e.g. Senior Backend Engineer"
							onfocus={() => titleTouched = true}
							onblur={() => titleTouched = true}
							style="width: 100%; padding: 12px 14px; border: 2px solid {titleError ? 'var(--color-error)' : 'var(--color-on-surface)'}; font-family: 'Space Grotesk'; font-size: 15px; font-weight: 700; background: var(--color-surface-bright);" />
						{#if titleError}
							<p style="font-size: 10px; color: var(--color-error); text-transform: uppercase; letter-spacing: 0.05em; margin-top: 4px;">{titleError}</p>
						{/if}
					</div>
					<div class="flex gap-3">
						<div class="flex-1">
							<label class="tag-label mb-1" style="display: block;">Department</label>
							<input bind:value={newDept} placeholder="Engineering"
								onfocus={() => deptTouched = true}
								onblur={() => deptTouched = true}
								style="width: 100%; padding: 10px 14px; border: 2px solid {deptWarning ? 'var(--color-warning)' : 'var(--color-on-surface)'}; font-family: 'Space Grotesk'; font-size: 13px; background: var(--color-surface-bright);" />
							{#if deptWarning}
								<p style="font-size: 10px; color: var(--color-warning); text-transform: uppercase; letter-spacing: 0.05em; margin-top: 4px;">{deptWarning}</p>
							{/if}
						</div>
						<div class="flex-1">
							<label class="tag-label mb-1" style="display: block;">Location</label>
							<input bind:value={newLocation} placeholder="Remote / San Francisco" style="width: 100%; padding: 10px 14px; border: 2px solid var(--color-on-surface); font-family: 'Space Grotesk'; font-size: 13px; background: var(--color-surface-bright);" />
						</div>
					</div>
					<div>
						<label class="tag-label mb-1" style="display: block;">Employment Type</label>
						<div class="flex gap-0" style="border: 2px solid var(--color-on-surface);">
							{#each ['full-time', 'part-time', 'contract', 'intern'] as t}
								<button
									onclick={() => newType = t}
									style="flex: 1; padding: 8px; font-family: 'Space Grotesk'; font-size: 10px; font-weight: 900; text-transform: uppercase; letter-spacing: 0.05em; border: none; cursor: pointer;
										background: {newType === t ? 'var(--color-on-surface)' : 'var(--color-surface-bright)'}; color: {newType === t ? 'var(--color-primary-container)' : 'var(--color-on-surface)'};"
								>{t}</button>
							{/each}
						</div>
					</div>
					<div style="background: var(--color-surface-container); padding: 12px 14px; border-left: 3px solid var(--color-primary);">
						<p style="font-size: 11px; color: var(--color-on-surface-dim); line-height: 1.5;">
							<span class="material-symbols-outlined" style="font-size: 14px; vertical-align: middle; color: var(--color-primary);">info</span>
							You can add the Job Description inside the position — generate with AI, attach from JD Repo, or write manually.
						</p>
					</div>
					<div class="flex gap-2 justify-end">
						<button class="btn-secondary" onclick={() => { showCreate = false; titleTouched = false; deptTouched = false; }}>Cancel</button>
						<button class="send-btn" onclick={createPosition} disabled={!titleValid || creating}>
							{creating ? 'Creating...' : 'Create & Open'}
						</button>
					</div>
				</div>
			</div>
		</div>
	{/if}

	<!-- Grid -->
	{#if loading}
		<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 section-animate">
			{#each [1,2,3] as _}
				<div class="skeleton" style="height: 220px;"></div>
			{/each}
		</div>
	{:else if positions.length === 0}
		<div class="flex flex-col items-center justify-center py-20 animate-fade-up" style="border: 3px dashed var(--color-outline-variant);">
			<span class="material-symbols-outlined" style="font-size: 48px; color: var(--color-on-surface-dim);">work_outline</span>
			<p style="font-size: 14px; font-weight: 900; text-transform: uppercase; margin-top: 12px;">No positions yet</p>
			<p style="font-size: 12px; color: var(--color-on-surface-dim); margin-top: 4px;">Create your first position to start hiring</p>
			<button class="send-btn mt-4" onclick={() => showCreate = true}>+ Create Position</button>
		</div>
	{:else}
		<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 section-animate">
			{#each positions as pos (pos.slug)}
				<a href="/positions/{pos.slug}" class="position-card" style="text-decoration: none; color: inherit; display: block; position: relative; {pos.status === 'closed' ? 'opacity: 0.6;' : ''}">
					{#if pos.status === 'closed'}
						<div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%) rotate(-15deg); z-index: 2; font-size: 28px; font-weight: 900; color: var(--color-error); border: 4px solid var(--color-error); padding: 4px 18px; text-transform: uppercase; letter-spacing: 0.1em; pointer-events: none; background: rgba(254,255,214,0.85);">
							CLOSED
						</div>
					{/if}
					<div class="dark-title-bar flex items-center gap-2">
						<span style="font-size: 16px;">{pos.icon || '💼'}</span>
						<span style="font-size: 12px; flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">{pos.title}</span>
						<span style="font-size: 9px; opacity: 0.6; padding: 1px 6px; border: 1px solid rgba(255,255,255,0.3);">{pos.status || 'active'}</span>
					</div>
					<div class="p-4">
						<div style="font-size: 11px; color: var(--color-on-surface-dim); text-transform: uppercase; letter-spacing: 0.05em;">
							{pos.department || 'No department'} {pos.location ? `· ${pos.location}` : ''}
						</div>

						<!-- Stats row -->
						<div class="flex gap-3 mt-3">
							<div class="flex items-center gap-1">
								<span class="tag-label" style="font-size: 8px;">CVs</span>
								<span style="font-size: 14px; font-weight: 900;">{pos.cv_count || 0}</span>
							</div>
							<div class="flex items-center gap-1">
								<span class="tag-label" style="font-size: 8px;">Short</span>
								<span style="font-size: 14px; font-weight: 900;">{pos.shortlisted || 0}</span>
							</div>
							<div class="flex items-center gap-1">
								<span class="tag-label" style="font-size: 8px;">Match</span>
								<span style="font-size: 14px; font-weight: 900;">{pos.avg_match ? `${pos.avg_match}%` : '—'}</span>
							</div>
						</div>

						<!-- Pipeline mini-bar -->
						{#if pos.cv_count > 0}
							<div class="mt-3">
								<div style="height: 6px; background: var(--color-surface-highest); border: 1px solid var(--color-outline-variant); display: flex; overflow: hidden;">
									{#each Object.entries(pos.pipeline || {}) as [stage, count]}
										{#if count > 0}
											<div style="width: {(count / pos.cv_count * 100)}%; background: {stageColors[stage] || '#9d9d91'}; min-width: 4px;"></div>
										{/if}
									{/each}
								</div>
								<div style="font-size: 9px; color: var(--color-on-surface-dim); margin-top: 2px; text-transform: uppercase;">
									Pipeline progress
								</div>
							</div>
						{/if}

						<!-- Health Score Indicator -->
						<div class="flex items-center gap-2 mt-3">
							<div style="flex: 1; height: 6px; background: var(--color-surface-highest); border: 1px solid var(--color-outline-variant); overflow: hidden;">
								<div style="width: {computeHealth(pos)}%; height: 100%; background: {healthColor(computeHealth(pos))}; transition: width 0.3s;"></div>
							</div>
							<span style="font-size: 10px; font-weight: 900; color: {healthColor(computeHealth(pos))}; white-space: nowrap; min-width: 80px; text-align: right;">
								{computeHealth(pos)}% {healthLabel(computeHealth(pos))}
							</span>
						</div>

					<!-- Actions -->
						<div class="flex gap-2 mt-4">
							<span class="send-btn" style="font-size: 10px; padding: 6px 12px; flex: 1; text-align: center;">Open</span>
							{#if pos.status === 'active'}
								<button class="btn-secondary" style="font-size: 10px; padding: 6px 12px;"
									onclick={(e) => archivePosition(e, pos.slug)}>Archive</button>
							{/if}
							<button style="font-size: 10px; padding: 6px 12px; border: 2px solid var(--color-error); color: var(--color-error); background: transparent; font-weight: 900; text-transform: uppercase; cursor: pointer;"
								onclick={(e) => askDeletePosition(e, pos)} title="Permanently delete">🗑 Delete</button>
						</div>
					</div>
				</a>
			{/each}
		</div>
	{/if}
</div>

<!-- ═══ POSITION HARD-DELETE CONFIRM MODAL ═══ -->
{#if posDeleteTarget}
	{@const _pt = (posDeleteTarget?.title || '').trim().toLowerCase()}
	{@const _pv = posDeleteConfirmText.trim().toLowerCase()}
	{@const _ok = _pv.length > 0 && (_pv === _pt || _pv === 'delete')}
	<div style="position: fixed; inset: 0; background: rgba(56,56,50,0.7); z-index: 200; display: flex; align-items: center; justify-content: center; padding: 20px;"
		onclick={(e) => { if (e.target === e.currentTarget && !posDeleting) { posDeleteTarget = null; posDeleteConfirmText = ''; } }}>
		<div class="ink-border stamp-shadow animate-fade-up" style="background: var(--color-surface); width: 520px; max-width: 95vw;">
			<div style="background: var(--color-error); color: white; padding: 8px 14px; font-size: 12px; font-weight: 900; text-transform: uppercase; letter-spacing: 0.06em;">
				⚠ PERMANENT DELETE — POSITION
			</div>
			<div class="p-5" style="display: flex; flex-direction: column; gap: 14px;">
				<p style="font-size: 13px; line-height: 1.5;">You are about to <strong style="color: var(--color-error);">permanently delete</strong> the position:</p>
				<div style="border: 2px solid var(--color-on-surface); padding: 10px 14px; background: var(--color-surface-bright); font-size: 13px; font-weight: 900;">
					{posDeleteTarget.title}
				</div>
				<p style="font-size: 11px; color: var(--color-on-surface-dim); text-transform: uppercase; letter-spacing: 0.04em; line-height: 1.5;">
					⚠ This cannot be undone. Candidates, scorecards, evaluations, JD link — all references removed. Only the creator or a superadmin may proceed.
				</p>
				<div>
					<label class="tag-label mb-1" style="display: block;">Type position name <strong style="color: var(--color-error);">{posDeleteTarget?.title}</strong> or word DELETE to confirm</label>
					<input type="text" bind:value={posDeleteConfirmText} placeholder={posDeleteTarget?.title || 'DELETE'}
						style="width: 100%; padding: 10px 14px; border: 2px solid var(--color-error); font-family: 'Space Grotesk'; font-size: 14px; font-weight: 700; letter-spacing: 0.1em; background: var(--color-surface-bright);" />
				</div>
				<div class="flex gap-2 justify-end pt-2">
					<button class="btn-secondary" disabled={posDeleting} onclick={() => { posDeleteTarget = null; posDeleteConfirmText = ''; }}>Cancel</button>
					<button onclick={confirmDeletePosition} disabled={posDeleting || !_ok}
						style="background: var(--color-error); color: white; border: 2px solid var(--color-on-surface); padding: 8px 18px; font-size: 11px; font-weight: 900; text-transform: uppercase; letter-spacing: 0.06em; cursor: {posDeleting ? 'wait' : 'pointer'}; opacity: {_ok ? 1 : 0.4};">
						{posDeleting ? 'DELETING…' : '🗑 PERMANENTLY DELETE'}
					</button>
				</div>
			</div>
		</div>
	</div>
{/if}
